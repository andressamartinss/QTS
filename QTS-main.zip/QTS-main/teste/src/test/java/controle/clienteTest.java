/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package controle;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Admin
 */
public class clienteTest {
    
    public clienteTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of posicionarRegistro method, of class cliente.
     */
    @Test
    public void testPosicionarRegistro() {
        System.out.println("posicionarRegistro");
        cliente instance = new cliente();
        instance.posicionarRegistro();
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of mostrar_Dados method, of class cliente.
     */
    @Test
    public void testMostrar_Dados() {
        System.out.println("mostrar_Dados");
        cliente instance = new cliente();
        instance.mostrar_Dados();
        // TODO review the generated test code and remove the default call to fail.
       
    }

    /**
     * Test of preencherTabela method, of class cliente.
     */
    @Test
    public void testPreencherTabela() {
        System.out.println("preencherTabela");
        cliente instance = new cliente();
        instance.preencherTabela();
        // TODO review the generated test code and remove the default call to fail.
       
    }
    
}
